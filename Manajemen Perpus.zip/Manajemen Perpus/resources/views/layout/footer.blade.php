<div class="footer">&copy; 2025 Delima</div>
</div>

</body>
</html>