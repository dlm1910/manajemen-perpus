<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>koleksiku</title> 
    <link rel="stylesheet" href="<?php echo e(asset('css/dashboard.css')); ?>">
</head>
<body>

<div class="wrapper">
    <div class="sidebar">
        <h2><span>k</span>oleksiku</h2>

        <a href="<?php echo e(route('dashboard')); ?>">Home</a>

        
        <?php if(auth()->user()->role === 'admin'): ?>
            <a href="<?php echo e(route('buku.index')); ?>">Buku</a>
            <a href="<?php echo e(route('kategori.index')); ?>">Kategori</a>
            <a href="<?php echo e(route('anggota.index')); ?>">Anggota</a>
            <a href="<?php echo e(route('peminjaman.index')); ?>">Peminjaman</a>
        <?php endif; ?>

        
        <?php if(auth()->user()->role === 'anggota'): ?>
            <a href="<?php echo e(route('buku.index')); ?>">Buku</a>
            <a href="<?php echo e(route('peminjaman.index')); ?>">Peminjaman Saya</a>
        <?php endif; ?>
    </div>

    <div class="main">
        <nav class="navbar">
            <div class="nav-left">
                <a href="<?php echo e(route('dashboard')); ?>" class="btn-home" style="text-decoration:none;">🏠 Home</a>
            </div>

            <div class="nav-right">
                <span>
                    Login sebagai: <b><?php echo e(auth()->user()->name); ?></b>
                    (<?php echo e(auth()->user()->role); ?>)
                </span>

                <form action="<?php echo e(route('logout')); ?>" method="POST" style="display:inline; margin-left: 10px;">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="btn-logout">Logout</button>
                </form>
            </div>
        </nav>

        <hr style="opacity: 0.1;">

        <main class="content">
            <?php echo $__env->yieldContent('content'); ?>
        </main>
    </div>
</div>

</body>
</html><?php /**PATH C:\Users\asus\Framework Project\crud-buku - Copy (2)\resources\views/layout/dashboard.blade.php ENDPATH**/ ?>