<?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<h3>Tambah Buku</h3>

<form action="<?php echo e(route('buku.store')); ?>" method="POST">
    <?php echo csrf_field(); ?>

    <div class="form-group">
        <label>Judul Buku</label>
        <input type="text" name="judul" required>
    </div>

    <div class="form-group">
        <label>Penulis</label>
        <input type="text" name="penulis" class="form-control" required>
    </div>
    
    <div class="form-group">
        <label>Kategori:</label>
        <select name="kategori_id">
            <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($k->id); ?>"><?php echo e($k->nama_kategori); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>

    <div class="form-group">
        <label>Tahun Terbit</label>
        <input type="number" name="tahun_terbit" required>
    </div>

    <div class="form-group">
        <label>Stok</label>
        <input type="number" name="stok" required>
    </div>

    <button type="submit" class="tombol">Simpan</button>
</form>

<?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\Users\asus\Framework Project\crud-buku - Copy (2)\resources\views/buku/create.blade.php ENDPATH**/ ?>