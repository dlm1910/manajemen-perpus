<?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<h3>Data Buku</h3>
<?php if(auth()->guard()->check()): ?>
    <?php if(auth()->user()->role === 'admin'): ?>
        <a href="<?php echo e(route('buku.create')); ?>" class="tombol">Tambah</a>
    <?php endif; ?>
<?php endif; ?>
<table border="1" cellpadding="8">
    <tr>
        <th>No</th>
        <th>Judul</th>
        <th>Penulis</th>
        <th>Tahun</th>
        <th>Stok</th>
        
        <?php if(auth()->user()->role === 'admin'): ?>
            <th>Aksi</th>
        <?php endif; ?>
    </tr>
<?php $__currentLoopData = $buku; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
    <td><?php echo e($loop->iteration); ?></td>
    <td><?php echo e($b->judul); ?></td>
    <td><?php echo e($b->penulis); ?></td>
    <td><?php echo e($b->tahun_terbit); ?></td>
    <td><?php echo e($b->stok); ?></td>
    <td>

        <?php if(auth()->user()->role === 'admin'): ?>
            <a href="<?php echo e(route('buku.show', $b->id)); ?>" class="tombol">Detail</a>
            <a href="<?php echo e(route('buku.edit', $b->id)); ?>" class="tombol">Edit</a>
            <form action="<?php echo e(route('buku.destroy', $b->id)); ?>" method="POST" style="display:inline">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button type="submit" class="tombol" onclick="return confirm('Yakin hapus data?')">
            Hapus
        </button>
              </form>
        <?php endif; ?>
    </td>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<br>
<a href="<?php echo e(route('dashboard')); ?>" class="tombol">Home</a>
<?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\Users\asus\Framework Project\crud-buku - Copy (2)\resources\views/buku/index.blade.php ENDPATH**/ ?>