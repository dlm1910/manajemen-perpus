
<?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<h3>Detail Buku</h3>

<table border="1" cellpadding="8" cellspacing="0">
    <tr>
        <td width="150">Judul Buku</td>
        <td width="10">:</td>
        <td><?php echo e($buku->judul); ?></td>
    </tr>
    <tr>
        <td>Tahun Terbit</td>
        <td>:</td>
        <td><?php echo e($buku->tahun_terbit); ?></td>
    </tr>
    <tr>
        <td>Penulis</td>
        <td>:</td>
        <td><?php echo e($buku->penulis); ?></td>
    </tr>

    <tr>
        <td>Stok</td>
        <td>:</td>
        <td><?php echo e($buku->stok); ?></td>
    </tr>
</table>

<br>
<a href="<?php echo e(route('buku.index')); ?>" class="tombol">Kembali</a>

<?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\Users\asus\Framework Project\crud-buku - Copy (2)\resources\views/buku/show.blade.php ENDPATH**/ ?>