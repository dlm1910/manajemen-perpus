<?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<h3>Edit Anggota</h3>

<form action="<?php echo e(route('anggota.update', $anggota)); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>

    <div class="form-group">
        <label>Nama Anggota:</label>
        <input type="text" name="nama" value="<?php echo e($anggota->nama); ?>">
    </div>

    <div class="form-group">
        <label>Alamat:</label>
        <input type="text" name="alamat" value="<?php echo e($anggota->alamat); ?>">
    </div>

    <div class="form-group">
        <label>No HP:</label>
        <input type="text" name="no_hp" value="<?php echo e($anggota->no_hp); ?>">
    </div>

    <button type="submit" class="tombol">Update</button>
</form>
<br>
<a href="<?php echo e(route('anggota.index')); ?>" class="tombol">Kembali</a>
<?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\Users\asus\Framework Project\crud-buku - Copy (2)\resources\views/anggota/edit.blade.php ENDPATH**/ ?>