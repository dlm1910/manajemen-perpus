<div class="footer">&copy; 2025 Delima</div>
</div>

</body>
</html><?php /**PATH C:\Users\asus\Framework Project\crud-buku - Copy (2)\resources\views/layout/footer.blade.php ENDPATH**/ ?>