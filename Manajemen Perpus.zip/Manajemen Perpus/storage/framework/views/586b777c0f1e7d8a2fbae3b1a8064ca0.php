

<?php $__env->startSection('content'); ?>
<h2>Selamat Datang, <?php echo e(auth()->user()->name); ?></h2>

<div class="cards">
    <div class="card blue">
        <h3>Jumlah Buku</h3>
        <p><?php echo e($jumlahBuku); ?></p>
    </div>

    <div class="card blue">
        <h3>Kategori</h3>
        <p><?php echo e($jumlahKategori); ?></p>
    </div>

    <div class="card blue">
        <h3>Anggota</h3>
        <p><?php echo e($jumlahAnggota); ?></p>
    </div>
    

    <div class="card blue">
        <h3>Pinjaman</h3>
        <p><?php echo e($jumlahPeminjaman); ?>

</p>
    </div>
</div>

<div class="info-box">
    <h3>Informasi Aturan Peminjaman</h3>
    <ol>
        <li>Maksimal peminjaman 1 minggu</li>
        <li>Maksimal 3 buku</li>
        <li>Denda Rp 15.000 / minggu</li>
        <li>Konfirmasi ke petugas</li>
    </ol>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\asus\Framework Project\crud-buku - Copy (2)\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>