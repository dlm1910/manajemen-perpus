<?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<h3>Edit Peminjaman</h3>

<form action="<?php echo e(route('peminjaman.update', $peminjaman->id)); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>

    <div class="form-group">
        <label>Anggota</label>
        <select name="anggota_id" class="form-control">
    <?php $__currentLoopData = $anggota; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($a->id); ?>" <?php echo e(isset($peminjaman) && $peminjaman->anggota_id == $a->id ? 'selected' : ''); ?>>
            <?php echo e($a->nama); ?> </option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>
    </div>
    

    <div class="form-group">
        <label>Buku</label>
        <select name="buku_id">
            <?php $__currentLoopData = $buku; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($b->id); ?>"
                    <?php echo e($peminjaman->buku_id == $b->id ? 'selected' : ''); ?>>
                    <?php echo e($b->judul); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>

    <div class="form-group">
        <label>Tanggal Pinjam</label>
        <input type="date" name="tanggal_pinjam"
               value="<?php echo e($peminjaman->tanggal_pinjam); ?>">
    </div>

    <div class="form-group">
        <label>Tanggal Kembali</label>
        <input type="date" name="tanggal_kembali"
               value="<?php echo e($peminjaman->tanggal_kembali); ?>">
    </div>

    <div class="form-group">
        <label>Status</label>
        <select name="status">
            <option value="dipinjam" <?php echo e($peminjaman->status == 'dipinjam' ? 'selected' : ''); ?>>
                Dipinjam
            </option>
            <option value="dikembalikan" <?php echo e($peminjaman->status == 'dikembalikan' ? 'selected' : ''); ?>>
                Dikembalikan
            </option>
        </select>
    </div>

    <button type="submit" class="tombol">Update</button>
</form>
<br>
<a href="<?php echo e(route('peminjaman.index')); ?>" class="tombol">Kembali</a>

<?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\Users\asus\Framework Project\crud-buku - Copy (2)\resources\views/peminjaman/edit.blade.php ENDPATH**/ ?>