<?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<h3>Data Peminjaman</h3>


<?php if(auth()->user()->role === 'admin'): ?>
    <a href="<?php echo e(route('peminjaman.create')); ?>" class="tombol">Tambah</a>
<?php endif; ?>

<table>
<thead>
    <tr>
        <th>No</th>
        <th>Anggota</th>
        <th>Buku</th>
        <th>Tanggal Pinjam</th>
        <th>Tanggal Kembali</th>
        <th>Status</th>
        
        <?php if(auth()->user()->role === 'admin'): ?>
            <th>Aksi</th>
        <?php endif; ?>
    </tr>
</thead>

<tbody>
<?php $__currentLoopData = $allPeminjaman; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tr>
    <td><?php echo e($key + 1); ?></td>
    <td><?php echo e($p->anggota->nama); ?></td>
    <td><?php echo e($p->buku->judul); ?></td>
    <td><?php echo e($p->tanggal_pinjam); ?></td>
    <td><?php echo e($p->tanggal_kembali ?? '-'); ?></td>
    <td><?php echo e($p->status ?? '-'); ?></td>

    
    <?php if(auth()->user()->role === 'admin'): ?>
    <td>
        <a href="<?php echo e(route('peminjaman.show', $p->id)); ?>" class="tombol">Detail</a>
        <a href="<?php echo e(route('peminjaman.edit', $p->id)); ?>" class="tombol">Edit</a>

        <form action="<?php echo e(route('peminjaman.destroy', $p->id)); ?>" method="POST" style="display:inline;">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <button type="submit" class="tombol" onclick="return confirm('Yakin hapus data?')">
                Hapus
            </button>
        </form>
    </td>
    <?php endif; ?>
</tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</tbody>
</table>
<br>
<a href="<?php echo e(route('dashboard')); ?>" class="tombol">Home</a>
<?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\asus\Framework Project\crud-buku - Copy (2)\resources\views/peminjaman/index.blade.php ENDPATH**/ ?>