<?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <h3>Buat Anggota</h3>
    <form action="<?php echo e(route('anggota.store')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="">Nama Anggota:</label>
            <input type="text" name="nama" id="" placeholder="Masukkan nama anggota">
</div>
<div class="form-group">
            <label for="">Alamat:</label>
            <input type="text" name="alamat" id="" placeholder="Masukkan alamat anggota">
</div>
<div class="form-group">
            <label for="">No Hp:</label>
            <input type="text" name="no_hp" id="" placeholder="Masukkan nomor anggota">
</div>
<button type="submit" class="tombol">submit</button>
</form>

<?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
<?php /**PATH C:\Users\asus\Framework Project\crud-buku - Copy (2)\resources\views/anggota/create.blade.php ENDPATH**/ ?>