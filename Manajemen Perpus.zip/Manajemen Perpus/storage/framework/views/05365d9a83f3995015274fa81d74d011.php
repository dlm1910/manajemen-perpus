<?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<h3>Edit Buku</h3>

<form action="<?php echo e(route('buku.update', $buku->id)); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>

    <div class="form-group">
        <label>Judul Buku</label>
        <input type="text" name="judul" value="<?php echo e($buku->judul); ?>" required>
    </div>

    <div class="form-group">
        <label>Kategori</label>
        <select name="kategori_id" required>
            <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($k->id); ?>"
                    <?php echo e($buku->kategori_id == $k->id ? 'selected' : ''); ?>>
                    <?php echo e($k->nama); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>

    <div class="form-group">
        <label>Penulis</label>
        <input type="text" name="penulis"
               value="<?php echo e($buku->penulis); ?>" required>
    </div>

    <div class="form-group">
        <label>Tahun Terbit</label>
        <input type="number" name="tahun_terbit"
               value="<?php echo e($buku->tahun_terbit); ?>" required>
    </div>

    <div class="form-group">
        <label>Stok</label>
        <input type="number" name="stok" value="<?php echo e($buku->stok); ?>" required>
    </div>

    <button type="submit" class="tombol">Update</button>
</form>

<br>
<a href="<?php echo e(route('buku.index')); ?>" class="tombol">Kembali</a>

<?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\Users\asus\Framework Project\crud-buku - Copy (2)\resources\views/buku/edit.blade.php ENDPATH**/ ?>